<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Validator;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Visitor;
use App\Message;
use App\Slides;
use App\Contact;
use App\Url;
use App\User;
use Auth;
use DB;
use Exporter;

class VisitorController extends Controller
{

	public function home()
	{
	    $slides = DB::table('slides')->get();
		return view('fe.home')->with('slides',$slides);
	}
    public function create()
    {
    	return view('fe.registration');
    }
    public function gallery()
    {
        return view('fe.gallery');
    }
    public function contact()
    {
        return view('fe.contact');
    }
    
    public function add_registration()
    {
    	return view('be.add_registration');
    }
    /*
     *addMessage
     */
   //addMessage
    public function addMessage(){
        $Message = Message::find(1);
        return view('be.add_message')->with('Message',$Message);
    }
    /*
     *addSlides/ Narayana
     */
    public function addSlides(){
        return view('be.add_slides');
    }
    public function edit_registration($id)
    {
        $visitor = Visitor::find($id);
        return view('be.edit_registration', compact('visitor'));
    }
   
    public function update_registration(Request $request, $id)
    {
        
        $visitor = Visitor::find($id);
        $validator = $this->validator($request->all());

    	if ($validator->fails()) {
    		$this->throwValidationException(
    			$request, $validator
    		);
    	}
    	$darshan_date = date('Y-m-d H:i:s', strtotime($request->darshan_date));
    	$accom_date = date('Y-m-d H:i:s', strtotime($request->accom_date));
    	$visitor->name = $request->name;
    	$visitor->mobile = $request->mobile;
        $visitor->total_members = $request->total_members;
        $visitor->darshan_type = $request->darshan_type;
        $visitor->darshan_date = $darshan_date;
        $visitor->accom_date = $accom_date;
        $visitor->reference = $request->reference;
        $visitor->ref_name = $request->ref_name;
        $visitor->remarks = $request->remarks;

        $visitor->save();
       // return redirect()->route('visitor', [$visitor->status]);

       return redirect()->route('visitor.status',[$visitor->status])->withSuccess('Visitor updated successfully');

    

    }
    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {

        
           return Validator::make($data, [
            'name' => 'required',
            'mobile' => 'required',
            'total_members' => 'required',
            'darshan_date' => 'required',
            'darshan_type' => 'required',
            'accom_date'=> 'required',
            'reference' => 'required',
            'ref_name' => 'required'
        ]); 
        
        
    }
   
    public  function send_sms($mobile, $message)
    {
        // http://bhashsms.com/api/sendmsg.php?user=amaraa&pass=amaraa1234&sender=amaraa&phone=9908372997&text=Test%20SMS&priority=ndnd&stype=normal
    	// Message details
    	$numbers = urlencode($mobile);
    	$sender = urlencode('amaraa');
    	$message = rawurlencode($message);
    	$username = 'amaraa';
    	$password = 'amaraa1234';
     
    	// Prepare data for POST request
    	$data = 'user='.$username.'&pass='.$password.'&sender='.$sender.'&phone='.$numbers.'&text='.$message.'&priority=ndnd&stype=normal';
     
    	// Send the GET request with cURL
    	$ch = curl_init('http://bhashsms.com/api/sendmsg.php?' . $data);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	$response = curl_exec($ch);
    	curl_close($ch);
    	
    	// Process your response here
    	return $response;
     
    }
    public function store(Request $request)
    {
        
         if($request->input('url')){ 
              $url = $request->input('url'); 
              $data = url::where('url',$url)->update(['status' => 1]);
           }
    	// dd($request->all());
    	$validator = $this->validator($request->all());

    	if ($validator->fails()) {
    		$this->throwValidationException(
    			$request, $validator
    		);
    	}
    	$request['darshan_date'] = date('Y-m-d H:i:s', strtotime($request->darshan_date));
    	$request['accom_date'] = date('Y-m-d H:i:s', strtotime($request->accom_date));
    	// dd($request->all());
    	$visitor = Visitor::create($request->all());
    	//$accom_date = date('d-m-Y', strtotime($request->accom_date));
        // $Message = Message::find(1);
        // $Msg     = explode('-',$Message->message);
    	//$message = $Msg[0].' '.$visitor->name.' '.$Msg[1].' '.$accom_date.' '.$Msg[2];
	    $message = 'శ్రీమతి/శ్రీ   '.$visitor->name.' గారు ,
    	మీరు స్వామి వారి దర్శనము కొరకు చేసుకొనిన Registration పూర్తి అయినది . తదుపరి సమాచారము కొరకు వేచిఉండగలరు .
        ..నమో వెంకటేశాయ @చైర్మన్ ఆఫీస్ , టీటీడీ';
    	$this->send_sms($request->mobile, $message);
    	return redirect()->back()->withSuccess('Visitor created successfully');

    }

    public function visitorContact(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
            'mobile' => 'required',
            'message' => 'required',
        ]);

        $contact = Contact::create($request->all());
        if($contact)
        {
            return redirect()->back()->withSuccess('Thanks for contacting us');
        }else
        {
            return redirect()->back()->withError('Sorry we have some issue');
        }

    }

    public function getVistorByStatus($status)
    {
        $from_date = !empty($_REQUEST['from_date'])?date('Y-m-d', strtotime($_REQUEST['from_date'])):date('Y-m-d');
        $to_date = !empty($_REQUEST['to_date'])?date('Y-m-d', strtotime($_REQUEST['to_date'])):date('Y-m-d',strtotime('+ 1 month'));
        if($status == 'all')
        {
            
             if(Auth::user()->user_type == 2 || Auth::user()->user_type == 1){
                 $visitors = DB::table('visitors')
              ->where('accom_date', '>=', $from_date)
               ->where('accom_date', '<=', $to_date)
               ->where('ref_name',Auth::user()->name)
              ->orderBy('accom_date','asc')
              ->get();

           }else{
           // $visitors = Visitor::orderBy('id','desc')->get();
             $visitors = DB::table('visitors')
              ->where('accom_date', '>=', $from_date)
               ->where('accom_date', '<=', $to_date)
              ->orderBy('accom_date','asc')
              ->get();
           }
        }else
        {
             if(Auth::user()->user_type == 2  || Auth::user()->user_type == 1){

            $visitors = DB::table('visitors')
              ->where('status', $status)
              ->where('accom_date', '>=', $from_date)
               ->where('accom_date', '<=', $to_date)
               ->where('ref_name',Auth::user()->name)
              ->orderBy('accom_date','asc')
              ->get();
          }else{
            //$visitors = Visitor::where('status',$status)->get(); 
            $visitors = DB::table('visitors')
              ->where('status', $status)
              ->where('accom_date', '>=', $from_date)
               ->where('accom_date', '<=', $to_date)
              ->orderBy('accom_date','asc')
              ->get();
          }
        }

        return view('be.visitors', compact('visitors','status','from_date','to_date'));
    }

    public function statusUpdate($id, $status, $remarks='')
    {
        
       $visitor = Visitor::find($id);
       $visitor->update(['status'=>$status, 'remarks'=>$remarks]);
       if($status == 'confirm')
       {
          $visitor->update(['staffstatus'=>'pending']); 
       }
        if($status =='aprove'){
        /* $message ='శ్రీమతి/శ్రీ  '.$visitor->name.' గారు ,
మీ అభ్యర్ధన  స్వీకరించటమయినది . మీరు స్వర్ణ తిరుమల గెస్ట్ హౌస్ నందు గల చైర్మన్ గారి ఆఫీసు లో   '.date('d-m-Y', strtotime($visitor->accom_date)).'  ఉదయం 10  గంటలకు సంప్రదించగలరు.

..నమో వెంకటేశాయ @చైర్మన్ ఆఫీస్ , టీటీడీ';*/
        $Message = Message::find(1);
        $Msg     = explode('-',$Message->message);
        $message = $Msg[0].' '.$visitor->name.' '.$Msg[1].' '.date('d-m-Y', strtotime($visitor->accom_date)).' '.$Msg[2];  
            $this->send_sms($visitor->mobile, $message);
        }else if ($status =='reject'){
            $message ='శ్రీమతి/శ్రీ  '.$visitor->name.' గారు ,
                మీరు కోరుకున్న రోజున అవకాశము లేనందు వలన మీ అభ్యర్ధనను స్వీకరించలేక పోతున్నాము . 
                ..నమో వెంకటేశాయ @చైర్మన్ ఆఫీస్ , టీటీడీ';
            $this->send_sms($visitor->mobile, $message);
        }
       return redirect()->back()->withSuccess('status changed successfully'); 
    }
    
    public function getVistorBystaffStatus($status)
    {
       
       // $visitors = Visitor::where('status',$status)->get();
       $from_date = !empty($_REQUEST['from_date'])?date('Y-m-d', strtotime($_REQUEST['from_date'])):date('Y-m-d');
        $to_date = !empty($_REQUEST['to_date'])?date('Y-m-d', strtotime($_REQUEST['to_date'])):date('Y-m-d',strtotime('+ 1 month'));
       if(Auth::user()->user_type == 2 || Auth::user()->user_type == 1){
           
           $visitors = DB::table('visitors')
                ->where('status', $status)
                ->where('ref_name',Auth::user()->name)
                 ->where('accom_date', '>=', $from_date)
               ->where('accom_date', '<=', $to_date)
               ->orderBy('name','asc')
              ->get();
       }else{
         $visitors = DB::table('visitors')
                ->where('status', $status)
                 ->where('accom_date', '>=', $from_date)
               ->where('accom_date', '<=', $to_date)
               ->orderBy('name','asc')
              ->get();
              
       }
        return view('be.staffvisitors', compact('visitors','status','from_date','to_date'));
    }
    public function staffstatusUpdate($id, $status)
    {
        // dd($id);
        $visitor = Visitor::find($id);
        $visitor->update(['status'=>$status]);
      // return redirect()->route('visitor.staffstatus',$status)->withSuccess('status changed successfully'); 
      return redirect()->back()->withSuccess('status changed successfully'); 
    }

    /*
      add Message
    */
      public function storeMessage(Request $request)
    {
        $this->validate($request, [
            'message' => 'required',
        ]);
        $visitor = Message::find(1);
        $visitor->message = $request->message;
        $message = $visitor->save();
        if($message)
        {
            return redirect()->back()->withSuccess('Message saved successfully');
        }else
        {
            return redirect()->back()->withError('Message save Failed');
        }

    }
    /*
      add Message 
      Narayana
    */
      public function storeSlides(Request $request)
    {
         // then put that name to $photoName variable.
        $photoName = time().'.'.$request->user_photo->getClientOriginalExtension();
        $request->user_photo->move(public_path('slides'), $photoName);
        $slides = new Slides();
        $slides->path = $photoName;
        $slides->createdBy = 1;
        $slides = $slides->save();
        if($slides)
        {
            return redirect()->back()->withSuccess('slide saved successfully');
        }else
        {
            return redirect()->back()->withError('slide save Failed');
        }

    }    
    /*
     *Referal
     */
    public function shareUrl(request $request){
      $this->validate($request, [
            'url' => 'required',
        ]);
        $mobile = $request->input('mobile'); 
        $url    = $request->input('url');
        //send sms
        $message = 'తిరుమల దర్శనం కొరకు ఈ '.$url.' క్లిక్ చేసి ,  ఫార్మ్ పూరించగలరు .'; 
        $message_status = $this->send_sms($request->mobile, $message); 
        //if(empty($message_status)){  echo "failed"; die;}else{echo $message_status;}   die;
        $url = new Url();
        $url->url = $request->input('url');
        $url->status = 0;
        $userdata = User::find(Auth::id());
        $url->userid = $userdata->id;
        $saveUrl = $url->save(); 
        if($saveUrl)
        {
            return redirect()->back()->withSuccess('Refere url successfully');
        }else
        {
            return redirect()->back()->withError('Refer url Failed');
        }

       
    }   
    
}
