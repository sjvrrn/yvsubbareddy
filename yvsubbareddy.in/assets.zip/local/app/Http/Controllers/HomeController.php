<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Visitor;
use DB;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {      
       // $visitors = Visitor::where('status','pending')->get(); 
        $from_date = !empty($_REQUEST['from_date'])?date('Y-m-d', strtotime($_REQUEST['from_date'])):date('Y-m-d');
        $to_date = !empty($_REQUEST['to_date'])?date('Y-m-d', strtotime($_REQUEST['to_date'])):date('Y-m-d',strtotime('+ 1 month'));
        if(isset(Auth::user()->user_type) && Auth::user()->user_type == 'staff'){
             $visitors = DB::table('visitors')
                ->where('status', 'aprove')
              ->where('accom_date', date('Y-m-d'))
              ->orderBy('name','asc')
              ->get();
            $title ='Approved List';
         }elseif(Auth::user()->user_type == 2 || Auth::user()->user_type == 1){

                 $visitors = DB::table('visitors')
                ->where('status', 'aprove')
                ->where('ref_name',Auth::user()->name)
              ->orderBy('name','asc')
              ->get();
            $title ='Approved List';

         }else{
         $visitors = DB::table('visitors')
                ->where('status', 'pending')
              ->where('accom_date', '>=', $from_date)
               ->where('accom_date', '<=', $to_date)
              ->orderBy('accom_date','asc')
              ->get();
        $title ='Pending List';
    }
        return view('home', compact('visitors','title','from_date','to_date'));
    }
}
