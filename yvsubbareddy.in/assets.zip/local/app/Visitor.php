<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Visitor extends Model
{
    public $table = 'visitors';
    protected $fillable =  ['name','mobile','total_members','darshan_date','darshan_type','accom_date','reference','ref_name','status','staffstatus','remarks'];
}

