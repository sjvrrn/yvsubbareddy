<?php $__env->startSection('content'); ?>
<div class="content">
    <?php if(Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                                <?php elseif( Session::has( 'warning' )): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(Session::get( 'warning' )); ?>

                                </div>
                                <?php endif; ?>
                    <div class="govt-section" ng-show="govtShow">
                            <div class="row">
                                <div class="col-md-9 col-xs-12 col-sm-12 mt-2">
                                <h3>Office staff List</h3> 
                                </div>
                                <div class="col-md-3 col-xs-12 col-sm-12 mt-2">
                                    <div style="float:right;font-weight:bold;font-size:20px;"><a href="<?php echo e(url('users/create')); ?>">Add New</a></div>
                                </div>
                                <div class="col-md-12 col-xs-12 col-sm-12 mt-2">
    	    			        <table id="example" class="display table-responsive" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Status</th>      
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                               
           
                                    <?php if(!empty($users)): ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                         <td><?php echo e($i+1); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?> </td>
                                        <td><?php if($user->status==1): ?>Active <?php else: ?> Inactive <?php endif; ?></td>
                                        <td>
                                        <a href="<?php echo e(url('users/edit/' . $user->id)); ?>"  >Edit</a>
                                        </td>    
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                               
                                </table>
                                </div>
                            </div>
                        </div>
                </div>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable({
			"bJQueryUI": true,
			"sPaginationType": "full_numbers",
			"aaSorting": [[ 1, 'asc' ]],
			"iDisplayLength": 100

		});
} );

</script>                
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>