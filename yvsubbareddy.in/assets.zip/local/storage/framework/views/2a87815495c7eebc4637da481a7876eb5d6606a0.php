<?php $__env->startSection('content'); ?>
<div class="container">
            <div class="pg-container" style="margin-bottom: 160px;">
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8 col-xs-12 col-sm-12">
                        <h4 class="abt-title mt-4">Log in</h4>
                        <div class="forgot-block">
                            
                                <form class="form-horizontal mt-2" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                                <div class="form-group row">
                                    <div class="col-md-3 text-align-right">
                                        User Email 
                                    </div>
                                    <div class="col-md-9">
                                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                        <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-3 text-align-right">
                                        Password 
                                    </div>
                                    <div class="col-md-9">
                                        <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                            <div class="col-md-3 text-align-right">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                                    <div class="col-md-3 text-align-right"><button type="submit" class="btn btn-primary">
                                    Login
                                </button></div>
                                    <div class="col-md-9 button-link"> 
                                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    Forgot Your Password?
                                </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-2"></div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>