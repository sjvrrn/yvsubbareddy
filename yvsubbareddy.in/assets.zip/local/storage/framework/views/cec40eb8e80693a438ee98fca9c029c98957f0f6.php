<?php $__env->startSection('content'); ?>
<div class="content">
	<?php if(Session::has('success')): ?>
	    			<div class="alert alert-success">
	    				<?php echo e(Session::get('success')); ?>

	    			</div>
	    			<?php elseif( Session::has( 'warning' )): ?>
	    			<div class="alert alert-danger">
	    				<?php echo e(Session::get( 'warning' )); ?>

	    			</div>
	    			<?php endif; ?>
	    	<div class="page-container card" style="margin-bottom: 180px;">
	    		
	    		<div class="row">
<?php  if($status>0){?>
	    			<div class=" offset-md-3 col-md-8 col-xs-12 col-sm-12">
	    				<h4 class="abt-title mt-4">Registration</h4>
	    				<!-- <form action="" class="mt-5" name="myForm">  -->
	    				<?php echo e(Form::open(array('route' => 'visitor.store','class' => 'form-horizontal mt-5', 'name'=>'myForm'))); ?>                       
	    				<div class="form-group row">
	    					<div class="col-md-3">
	    						Name <span class="style1">&nbsp;*</span>
	    					</div>
	    					<div class="col-md-9">
	    						
	    						<?php echo e(Form::text('name',null,array('class' => 'form-control','placeholder'=>'Enter Name','required'))); ?>

	    						
	    						<?php if($errors->has('name')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('name')); ?></strong>
	    						</span> 
	    						<?php endif; ?> 
	    					</div>
	    				</div>
	                        
	                        <div class="form-group row">
	                            <div class="col-md-3">
	                                Mobile <span class="style1">&nbsp;*</span>
	                            </div>
	                            <div class="col-md-9">
	                               
	                                <?php echo e(Form::text('mobile',null,array('class' => 'form-control','placeholder'=>'Enter your Mobile No','required'))); ?>

	    						
	    						<?php if($errors->has('mobile')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('mobile')); ?></strong>
	    						</span> 
	    						<?php endif; ?>
	                            </div>
	                        </div>
	                        <div class="form-group row">
	                            <div class="col-md-3">
	                                Total Members <span class="style1">&nbsp;*</span>
	                            </div>
	                            <div class="col-md-9">
	                                
	                                <?php echo e(Form::text('total_members',null,array('class' => 'form-control','placeholder'=>'Enter your total No','required'))); ?>

	    						
	    						<?php if($errors->has('total_members')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('total_members')); ?></strong>
	    						</span> 
	    						<?php endif; ?>
	                            </div>
	                        </div>
	                        <div class="form-group row">
	                            <div class="col-md-3">
	                                Darshanam Date <span class="style1">&nbsp;*</span>
	                            </div>
	                            <div class="col-md-9">
	                                
	                                <?php echo e(Form::date('darshan_date',null,array('class' => 'form-control','placeholder'=>'yyyy-mm-dd','required', 'min' =>  date('Y-m-d')))); ?> 
	                                <?php if($errors->has('darshan_date')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('darshan_date')); ?></strong>
	    						</span> 
	    						<?php endif; ?>
	                            </div>
	                        </div>
	                        <div class="form-group row">
	                            <div class="col-md-3">
	                                Darshanam Type <span class="style1">&nbsp;*</span>
	                            </div>
	                            <div class="col-md-9">
	                                
	                                <?php echo e(Form::text('darshan_type',null,array('class' => 'form-control','placeholder'=>'Eg: Special','required'))); ?> 
	                                <?php if($errors->has('darshan_type')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('darshan_type')); ?></strong>
	    						</span> 
	    						<?php endif; ?>
	                            </div>
	                        </div>
	                        <div class="form-group row">
	                            <div class="col-md-3">
	                                Accomidation Date <span class="style1">&nbsp;*</span>
	                            </div>
	                            <div class="col-md-9">
	                                <?php echo e(Form::date('accom_date',null,array('class' => 'form-control','placeholder'=>'yyyy-mm-dd','required', 'min' =>  date('Y-m-d')))); ?> 
	                                <?php if($errors->has('accom_date')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('accom_date')); ?></strong>
	    						</span> 
	    						<?php endif; ?>
	                            </div>
	                        </div>
	                        <div class="form-group row mt-2">
	                            <div class="col-md-3">
	                                Reference <span class="style1">&nbsp;*</span>
	                            </div>
	                            <div class="col-md-9">
	                                <select name="reference" class="form-control" id="reference" required>
                                    
                                    <option value="MLA">MLA</option>
                                    <option value="MP">MP</option>
                                    <option value="Other">Other</option>
                                    
                                </select>
                                <?php if($errors->has('reference')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('reference')); ?></strong>
                                </span>
                                <?php endif; ?>
	                            </div>
	                        </div>
	                        <div class="form-group row">
	                            <div class="col-md-3">
	                                Ref Name <span class="style1">&nbsp;*</span>
	                            </div>
	                            <div class="col-md-9">
	                                
	                                <?php echo e(Form::text('ref_name',null,array('class' => 'form-control','placeholder'=>'Eg: YV Subbareddy garu','required'))); ?> 
	                                <?php if($errors->has('ref_name')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('ref_name')); ?></strong>
	    						</span> 
	    						<?php endif; ?>
	                            </div>
	                        </div>
	                        <input type="hidden" name="url" value="<?=Request::url();?>">
	                        <div class="form-group row">
	                            <div class="col-md-3">&nbsp;</div>
	                            <div class="col-md-9"> 
	                            	<?php echo e(Form::token()); ?>

	                                <input id="input-submit" value="Submit" type="submit" class="btn btn-success">
	                            </div>
	                        </div>

                     
                    <?php echo e(Form::close()); ?>

                        
	    			</div>
	    		<?php  }else{

echo'<div class="alert alert-danger col-md-12">
	    				Invalid Url Please Try Again.
	    			</div>';
	    		}?>
	    			
	    		</div>
	    	</div>
	    </div>
	    <?php $__env->stopSection(); ?>
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	    <script>
	    	$(document).ready(function(){ console.log('hello');
                     $(".container").css('display','none');
                     $(".navbar").css('display','none');

	    	})

	    </script>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>