<?php $__env->startSection('content'); ?>
<div class="content">
    <?php if(Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                                <?php elseif( Session::has( 'warning' )): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(Session::get( 'warning' )); ?>

                                </div>
                                <?php endif; ?>
                    <div class="page-container card" style="margin-bottom: 180px;">
	    		<h4 class="abt-title mt-4">Change Password</h4>
	    		<div class="row">

	    			<div class="col-md-8 col-xs-12 col-sm-12">
	    				<?php echo e(Form::open(array('route' =>[ 'user.change_password_post'],'class' => 'form-horizontal mt-5', 'name'=>'myForm'))); ?>                       
	    				
	                   <div class="form-group row">
	    					<div class="col-md-3">
	    						Current Password <span class="style1">&nbsp;*</span>
	    					</div>
	    					<div class="col-md-9">
	    						
	    						<?php echo e(Form::text('current-password',null,array('class' => 'form-control','placeholder'=>'Enter Current Password','required'))); ?>

	    						
	    						<?php if($errors->has('current-password')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('current-password')); ?></strong>
	    						</span> 
	    						<?php endif; ?> 
	    					</div>
	    				</div> 
	    				<div class="form-group row">
	    					<div class="col-md-3">
	    						New Password <span class="style1">&nbsp;*</span>
	    					</div>
	    					<div class="col-md-9">
	    						
	    						<?php echo e(Form::password('password',array('class' => 'form-control','placeholder'=>'Enter Password','required'))); ?>

	    						
	    						<?php if($errors->has('password')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('password')); ?></strong>
	    						</span> 
	    						<?php endif; ?> 
	    					</div>
	    				</div> 
	    				<div class="form-group row">
	    					<div class="col-md-3">
	    						Confirm New Password <span class="style1">&nbsp;*</span>
	    					</div>
	    					<div class="col-md-9">
	    						
	    						<?php echo e(Form::password('password_confirmation',array('class' => 'form-control','placeholder'=>'Enter Password','required'))); ?>

	    						
	    						<?php if($errors->has('password_confirmation')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('password_confirmation')); ?></strong>
	    						</span> 
	    						<?php endif; ?> 
	    					</div>
	    				</div> 
	                       
	                        <div class="form-group row">
	                            <div class="col-md-3">&nbsp;</div>
	                            <div class="col-md-9"> 
	                            	<?php echo e(Form::token()); ?>

	                                <input id="input-submit" value="Submit" type="submit" class="btn btn-success">
	                            </div>
	                        </div>

                     
                    <?php echo e(Form::close()); ?>

                        
	    			</div>
	    			
	    		</div>
	    	</div>
	    </div>
	    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>