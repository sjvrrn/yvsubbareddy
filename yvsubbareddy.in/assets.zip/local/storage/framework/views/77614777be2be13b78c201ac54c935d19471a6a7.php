<?php $__env->startSection('content'); ?>
<div class="content">
    <?php if(Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                                <?php elseif( Session::has( 'warning' )): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(Session::get( 'warning' )); ?>

                                </div>
                                <?php endif; ?>
                    <div class="govt-section" ng-show="govtShow">
                            <div class="row">
                                <div style="float:right;width:100%;text-align:right" class="no-print"><input type='button' id='print-view' value='Print' onclick='printDiv();' class="btn btn-error"></div>
                                <div  id="DivIdToPrint">
                                <h3><?php echo e(ucwords($status)); ?> List</h3>
                                <div class="col-md-12 col-xs-12 col-sm-12 mt-2">
                                

	                            <div  class="print-only">
                                    <div class="form-group row" style ="font-weight:bold;">
        	                            <div style="float:left;width:50%">
        	                                From Date : <?php echo e(date('d-m-Y', strtotime($from_date))); ?>

        	                                
        	                            </div>
        	                            <div  style="float:left;width:50%">
        	                                To Date :<?php echo e(date('d-m-Y', strtotime($to_date))); ?>

        	                            </div>
    	                            </div>
                                </div>
                  
                                <div  class="no-print">
    	    			    	<?php echo e(Form::open(array('class' => 'form-horizontal mt-5', 'name'=>'myForm'))); ?>                       
    	    				     <div class="form-group row">
    	                            <div class="col-md-3">
    	                                From Date <span class="style1">&nbsp;*</span>
    	                               <?php echo e(Form::date('from_date',$from_date,array('class' => 'form-control','placeholder'=>'yyyy-mm-dd','required'))); ?> 
    	                                <?php if($errors->has('from_date')): ?>
    	    						    <span class="help-block">
    	    						    	<strong><?php echo e($errors->first('from_date')); ?></strong>
    	    					    	</span> 
    	    					    	<?php endif; ?>
    	                            </div>
    	                            <div class="col-md-3">
    	                                To Date <span class="style1">&nbsp;*</span>
    	                                <?php echo e(Form::date('to_date',$to_date,array('class' => 'form-control','placeholder'=>'yyyy-mm-dd','required'))); ?> 
    	                                <?php if($errors->has('to_date')): ?>
    	    					    	<span class="help-block">
    	    							    <strong><?php echo e($errors->first('to_date')); ?></strong>
    	    					    	</span> 
    	    					    	<?php endif; ?>
    	                            </div>
    	                            <div class="col-md-3"> 
    	                                 <?php echo e(Form::token()); ?>

    	                                <input id="input-submit" value="Submit" type="submit" class="btn btn-success">
    	                            </div>
    	                        </div>
    	                        <?php echo e(Form::close()); ?>

    	                        </div>
                                <table id="example" class="display table-responsive" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Mobile</th>
                                            <th>Total Number</th>
                                            <th>Darshan Date</th>
                                            <th>Darshan Type</th>
                                            <th>Accomidation Date</th>
                                            <th>Reference</th>
                                            <th>Reference Name</th>
                                            <th>Remarks</th>
                                            <th class="no-print">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                               
           
                                    <?php if(!empty($visitors)): ?>
                                    <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                         <td><a href="<?php echo e(url('edit_registration/' . $visitor->id)); ?>"  class="update_reg" title="Edit"><?php echo e($i+1); ?></a></td>
                                        <td><?php echo e($visitor->name); ?></td>
                                        <td><?php echo e($visitor->mobile); ?> </td>
                                        <td><?php echo e($visitor->total_members); ?></td>
                                        <td><span style="display:none"><?php echo e(strtotime($visitor->darshan_date)); ?></span> <?php echo e(date('d-m-Y',strtotime($visitor->darshan_date))); ?> </td>
                                        <td> <?php echo e($visitor->darshan_type); ?> </td>
                                        <td><span style="display:none"><?php echo e(strtotime($visitor->accom_date)); ?></span>  <?php echo e(date('d-m-Y',strtotime($visitor->accom_date))); ?></td>
                                        <td> <?php echo e($visitor->reference); ?></td>
                                        <td> <?php echo e($visitor->ref_name); ?></td>
                                         <td> <?php echo e($visitor->remarks); ?></td>
                                        <td  class="no-print">
                                        <p>
                                        <?php if($status == 'pending'): ?>
                                        <a href="<?php echo e(url('visitorstatus/' . $visitor->id . '/aprove')); ?>"  class="update_status"><img src="<?php echo e(url('assets/images/approve.png')); ?>" alt="Approve" title="Approve"  style="width:20px;" ></a>&nbsp;&nbsp;<a href="<?php echo e(url('visitorstatus/' . $visitor->id . '/reject')); ?>"    class="update_status" ><img src="<?php echo e(url('assets/images/reject.png')); ?>" alt="Reject" title="Reject"  style="width:20px;" >&nbsp;
                                                </a>
                                            
                                            <?php elseif($status == 'aprove'): ?>
                                            <!-- a href="<?php echo e(url('visitorstatus/' . $visitor->id . '/confirm')); ?>"   onclick="return confirm('Are you sure, you want to change the status of #<?php echo e($visitor->id); ?>?')">
                                                <img src="<?php echo e(url('assets/images/confirm.png')); ?>" alt="Confirm" title="Confirm"  style="width:20px;" >&nbsp;
                                               </a>&nbsp;&nbsp; -->
                                                <a href="<?php echo e(url('visitorstatus/' . $visitor->id . '/reject')); ?>"    class="update_status">
                                                    <img src="<?php echo e(url('assets/images/reject.png')); ?>" alt="Reject" title="Reject"  style="width:20px;" >&nbsp;
                                                </a>
                                                <!-- <a href="<?php echo e(url('/printuser/' . $visitor->id)); ?>"  id="user-delete" target="_blank">
                                                <img src="<?php echo e(url('assets/images/print_user.png')); ?>" alt="print user" title="printuser"  style="width:20px;" >&nbsp;
                                                </a>-->
                                            <?php elseif($status == 'reject'): ?>
                                            <a href="<?php echo e(url('visitorstatus/' . $visitor->id . '/aprove')); ?>"    class="update_status">
                                                <img src="<?php echo e(url('assets/images/approve.png')); ?>" alt="Approve" title="Approve"  style="width:20px;" >&nbsp;
                                                </a>
                                            
                                            <?php elseif($status == 'confirm'): ?>
                                                <?php echo e($visitor->status); ?>

                                            <?php elseif($status == 'all'): ?>
                                              <?php echo e($visitor->status); ?>  
                                            <?php else: ?>
                                            <?php endif; ?>
                                            </p>
                                             
                                        </td>    
                                    </tr>

                                    <!--div class="card">
                                        <div class="card-body ml-4">
                                            <p><strong>Name: </strong> <?php echo e($visitor->name); ?> </p>
                                            <p><strong>Mobile: </strong> <?php echo e($visitor->mobile); ?> </p>
                                            <p><strong>Total Number: </strong> <?php echo e($visitor->total_members); ?> </p>
                                            <p><strong>Darshan Date: </strong> <?php echo e($visitor->darshan_date); ?> </p>
                                            <p><strong>Darshan Type: </strong> <?php echo e($visitor->darshan_type); ?> </p>
                                            <p><strong>Accomidation Date: </strong> <?php echo e($visitor->accom_date); ?> </p>
                                            <p><strong>Reference: </strong> <?php echo e($visitor->reference); ?> </p>
                                            <p><strong>Reference Name: </strong> <?php echo e($visitor->ref_name); ?> </p>
                                            <?php if($status == 'pending'): ?>
                                           
                                            <p><a href="<?php echo e(url('visitorstatus/ ' . $visitor->id . '/aprove')); ?>" class="btn btn-success">Approve&nbsp;
                                                <i class="fas fa-edit"></i></a>
                                                <a href="<?php echo e(url('visitorstatus/ ' . $visitor->id . '/reject')); ?>" class="btn btn-danger">Reject&nbsp;
                                                <i class="fas fa-delete"></i></a>
                                            </p>
                                            <?php elseif($status == 'aprove'): ?>
                                            <p><a href="<?php echo e(url('visitorstatus/ ' . $visitor->id . '/confirm')); ?>" class="btn btn-success">Conform&nbsp;
                                                <i class="fas fa-edit"></i></a>
                                                <a href="<?php echo e(url('visitorstatus/ ' . $visitor->id . '/reject')); ?>" class="btn btn-danger">Reject&nbsp;
                                                <i class="fas fa-delete"></i></a>
                                            </p>
                                            <?php elseif($status == 'reject'): ?>
                                            <p><a href="<?php echo e(url('visitorstatus/ ' . $visitor->id . '/aprove')); ?>" class="btn btn-success">Approve&nbsp;
                                                <i class="fas fa-edit"></i></a>
                                            </p>
                                            <?php elseif($status == 'confirm'): ?>
                                            <!-- <p><a href="#" class="btn btn-success">Conform&nbsp;
                                                <i class="fas fa-edit"></i></a>
                                                <a href="#" class="btn btn-danger">Reject&nbsp;
                                                <i class="fas fa-delete"></i></a>
                                            </p> 
                                            <?php else: ?>
                                            <?php endif; ?>
                                        </div>
                                    </div-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                               
                                </table>
                                </div>
                                </div>
                            </div>
                        </div>
                </div>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script>
function printDiv(){
	var divToPrint = document.getElementById('DivIdToPrint');
	var popupWin = window.open('', '_blank', 'width=900,height=700,scrollbars=1,resizable=1');
	popupWin.document.open();
	popupWin.document.write('<html><head><link rel="stylesheet" href="style.css" type="text/css" /><style>@page  { size: landscape; }			table{border-collapse:collapse;} table td, table th {border: black 1px solid;vertical-align:top;padding:5px;}th{text-align:left}#example_length,#example_filter,#example_info,#example_paginate,.no-print{display:none;}.print-only, .print-only-table {display:block;}</style></head><body  onload="window.print()">'+  divToPrint.innerHTML +  '</body></html>'); 
	popupWin.document.close();
			
}	

$(".update_status").click(function(e){
     var remarks = prompt("Please enter if any remarks (optional)", "");
    e.preventDefault();
    var href = $(this).attr("href")+'/'+remarks;
    window.location = href;
});

$(document).ready(function() {
    $('#example').DataTable({
			"bJQueryUI": true,
			"sPaginationType": "full_numbers",
			"aaSorting": [[ 6, 'asc' ]],
			"iDisplayLength": 100

		});
} );

</script>                
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>