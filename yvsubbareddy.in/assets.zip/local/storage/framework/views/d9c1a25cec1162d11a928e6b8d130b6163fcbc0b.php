<?php $__env->startSection('content'); ?>
<style>
.url{
    font-family:serif;
}
#url{
    width:300px;
    border:1px solid #d0b9b9;
}
#note{
    color:brown;
}
</style>
<div class="content">
	<?php if(Session::has('success')): ?>
	    			<div class="alert alert-success">
	    				<?php echo e(Session::get('success')); ?>

	    			</div>
	    			<?php elseif( Session::has( 'warning' )): ?>
	    			<div class="alert alert-danger">
	    				<?php echo e(Session::get( 'warning' )); ?>

	    			</div>
	    			<?php endif; ?>
	    	<div class="page-container card" style="margin-bottom: 180px;">
	    		<h4 class="abt-title mt-4 url">Refer Url</h4>
	    		<div class="row">

	    			<div class="col-md-8 col-xs-12 col-sm-12">
	    				<!-- <form action="" class="mt-5" name="myForm">  -->
	    				<?php echo e(Form::open(array('route' => 'user.shareurl','class' => 'form-horizontal mt-5', 'name'=>'myForm'))); ?>                       
	    			
	                       <div class="form-group row">
	                            <div class="col-md-3 url control-label" >URL:</div>
	                            <div class="col-md-9"> 
	                            	 <input type='text' class="form-control" name='url' value="<?=$url?>" class='url' id="url"/>
	                            	  <p class="url" id='note'>* use (ctl+A) to select Test</p>
	                            </div>
	                           
	                        </div>
	                        <div class="form-group row">
	                            <div class="col-md-3">
	                                Mobile <span class="style1">&nbsp;*</span>
	                            </div>
	                            <div class="col-md-9">
	                                <?php echo e(Form::text('mobile',null,array('class' => 'form-control','placeholder'=>'Enter your Mobile No','required'))); ?>

	    						</div>
	                        </div>
	                        <div class="form-group row">
	                            <div class="col-md-3">&nbsp;</div>
	                            <div class="col-md-9"> 
	                            	<?php echo e(Form::token()); ?>

	                                <input id="input-submit" value="Submit" type="submit" class="btn btn-success">
	                            </div>
	                        </div>

                     
                    <?php echo e(Form::close()); ?>

                        
	    			</div>
	    			
	    		</div>
	    	</div>
	    </div>
	    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>