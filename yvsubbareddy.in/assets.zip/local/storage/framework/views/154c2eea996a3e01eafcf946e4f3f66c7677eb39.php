<?php $__env->startSection('content'); ?>
<div class="content">
    <?php if(Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                                <?php elseif( Session::has( 'warning' )): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(Session::get( 'warning' )); ?>

                                </div>
                                <?php endif; ?>
                    <div class="page-container card" style="margin-bottom: 180px;">
	    		<h4 class="abt-title mt-4">Update Office staff</h4>
	    		<div class="row">

	    			<div class="col-md-8 col-xs-12 col-sm-12">
	    				<?php echo e(Form::open(array('route' =>[ 'user.update', $user->id],'class' => 'form-horizontal mt-5', 'name'=>'myForm'))); ?>                       
	    				<div class="form-group row">
	    					<div class="col-md-3">
	    						Name <span class="style1">&nbsp;*</span>
	    					</div>
	    					<div class="col-md-9">
	    						
	    						<?php echo e(Form::text('name',$user->name,array('class' => 'form-control','placeholder'=>'Enter Name','required'))); ?>

	    						
	    						<?php if($errors->has('name')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('name')); ?></strong>
	    						</span> 
	    						<?php endif; ?> 
	    					</div>
	    				</div>
	                   <div class="form-group row">
	    					<div class="col-md-3">
	    						Email <span class="style1">&nbsp;*</span>
	    					</div>
	    					<div class="col-md-9">
	    						
	    						<?php echo e(Form::text('email',$user->email,array('class' => 'form-control','placeholder'=>'Enter Email','required'))); ?>

	    						
	    						<?php if($errors->has('email')): ?>
	    						<span class="help-block">
	    							<strong><?php echo e($errors->first('email')); ?></strong>
	    						</span> 
	    						<?php endif; ?> 
	    					</div>
	    				</div> 
	                   	<div class="form-group row mt-2">
	                            <div class="col-md-3">
	                                Status <span class="style1">&nbsp;*</span>
	                            </div>
	                            <div class="col-md-9">
	                                <?php echo e(Form::select('status', array('1' => 'Active', '0' => 'Inactive') ,$user->status ,array('class' => 'form-control','required'))); ?>

                                <?php if($errors->has('status')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('status')); ?></strong>
                                </span>
                                <?php endif; ?>
	                            </div>
	                        </div>
	                       
	                        <div class="form-group row">
	                            <div class="col-md-3">&nbsp;</div>
	                            <div class="col-md-9"> 
	                            	<?php echo e(Form::token()); ?>

	                                <input id="input-submit" value="Submit" type="submit" class="btn btn-success">
	                            </div>
	                        </div>

                     
                    <?php echo e(Form::close()); ?>

                        
	    			</div>
	    			
	    		</div>
	    	</div>
	    </div>
	    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>